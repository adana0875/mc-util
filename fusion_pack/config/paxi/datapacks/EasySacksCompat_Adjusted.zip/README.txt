# Easy Sacks Compat

> Supplementaries Sacks and Easy Shulker Boxes Compat

This datapack allows sacks added by the mods [Supplementaries](https://modrinth.com/mod/supplementaries) and [Supplementaries Squared](https://modrinth.com/mod/supplementaries-squared), to become compatible with the [Easy Shulker Boxes](https://modrinth.com/mod/easy-shulker-boxes) mod.

If you need this compat for an older version of Minecraft, checkout [EasyShulkerBoxes Supplementaries Sacks Compat](https://modrinth.com/datapack/easyshulkerboxes-supplementaries-compat).

---

### Dev notes

Compat was created from following the examples provided by the [EasyShulkerBoxes mod on GitHub](https://github.com/Fuzss/easyshulkerboxes/blob/main/1.21.1/Common/src/generated/resources/data/easyshulkerboxes/item_contents_provider/white_shulker_box.json).
